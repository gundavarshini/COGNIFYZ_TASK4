const express = require("express");
const path = require("path");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files
app.use(express.static(path.join(__dirname, "public")));

// EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Home page
app.get("/", (req, res) => {
    res.render("index", {
        success: null,
        errors: [],
        formData: {}
    });
});

// Registration
app.post("/register", (req, res) => {

    const {
        fullName,
        email,
        phone,
        password,
        confirmPassword
    } = req.body;

    const errors = [];

    // Full name validation
    if (!fullName || fullName.trim() === "") {
        errors.push("Full name is required.");
    } else if (fullName.trim().length < 3) {
        errors.push("Full name must contain at least 3 characters.");
    } else if (!/^[A-Za-z ]+$/.test(fullName.trim())) {
        errors.push("Full name can contain only letters and spaces.");
    }

    // Email validation
    if (!email || email.trim() === "") {
        errors.push("Email address is required.");
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        errors.push("Please enter a valid email address.");
    }

    // Phone validation
    if (!phone || phone.trim() === "") {
        errors.push("Phone number is required.");
    } else if (!/^[0-9]{10}$/.test(phone.trim())) {
        errors.push("Phone number must contain exactly 10 digits.");
    }

    // Password validation
    if (!password) {
        errors.push("Password is required.");
    } else {

        if (password.length < 8) {
            errors.push("Password must contain at least 8 characters.");
        }

        if (!/[A-Z]/.test(password)) {
            errors.push("Password must contain at least one uppercase letter.");
        }

        if (!/[a-z]/.test(password)) {
            errors.push("Password must contain at least one lowercase letter.");
        }

        if (!/[0-9]/.test(password)) {
            errors.push("Password must contain at least one number.");
        }

        if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            errors.push("Password must contain at least one special character.");
        }
    }

    // Confirm password
    if (!confirmPassword) {
        errors.push("Please confirm your password.");
    } else if (password !== confirmPassword) {
        errors.push("Passwords do not match.");
    }

    // Return validation errors
    if (errors.length > 0) {
        return res.status(400).render("index", {
            success: null,
            errors: errors,
            formData: {
                fullName,
                email,
                phone
            }
        });
    }

    // Successful registration
    res.render("index", {
        success: "Registration completed successfully!",
        errors: [],
        formData: {}
    });
});

// Client-side route examples
app.get("/home", (req, res) => {
    res.redirect("/");
});

app.get("/register", (req, res) => {
    res.redirect("/#register");
});

// 404 handler
app.use((req, res) => {
    res.status(404).send(`
        <h1>404 - Page Not Found</h1>
        <p>The requested page does not exist.</p>
        <a href="/">Go to Home</a>
    `);
});

// Start server
app.listen(PORT, () => {
    console.log("==============================================");
    console.log(" Cognifyz Level 2 - Task 4");
    console.log(" Complex Form Validation");
    console.log(" Dynamic DOM Manipulation");
    console.log("==============================================");
    console.log(`Server running at: http://localhost:${PORT}`);
});