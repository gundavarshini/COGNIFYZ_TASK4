/* =========================================================
   ELEMENTS
========================================================= */

const form = document.getElementById("registrationForm");

const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const terms = document.getElementById("terms");

const strengthBar = document.getElementById("strengthBar");
const strengthText = document.getElementById("strengthText");

const dynamicMessage =
    document.getElementById("dynamicMessage");


/* =========================================================
   ERROR ELEMENTS
========================================================= */

const fullNameError =
    document.getElementById("fullNameError");

const emailError =
    document.getElementById("emailError");

const phoneError =
    document.getElementById("phoneError");

const passwordError =
    document.getElementById("passwordError");

const confirmPasswordError =
    document.getElementById("confirmPasswordError");

const termsError =
    document.getElementById("termsError");


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function setError(input, errorElement, message) {

    input.classList.remove("valid");

    input.classList.add("invalid");

    errorElement.textContent = message;
}


function setValid(input, errorElement) {

    input.classList.remove("invalid");

    input.classList.add("valid");

    errorElement.textContent = "";
}


function clearValidation(input, errorElement) {

    input.classList.remove("valid");

    input.classList.remove("invalid");

    errorElement.textContent = "";
}


/* =========================================================
   FULL NAME VALIDATION
========================================================= */

function validateFullName() {

    const value = fullName.value.trim();

    if (value === "") {

        setError(
            fullName,
            fullNameError,
            "Full name is required."
        );

        return false;
    }

    if (value.length < 3) {

        setError(
            fullName,
            fullNameError,
            "Name must contain at least 3 characters."
        );

        return false;
    }

    if (!/^[A-Za-z ]+$/.test(value)) {

        setError(
            fullName,
            fullNameError,
            "Name can contain only letters and spaces."
        );

        return false;
    }

    setValid(fullName, fullNameError);

    return true;
}


/* =========================================================
   EMAIL VALIDATION
========================================================= */

function validateEmail() {

    const value = email.value.trim();

    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (value === "") {

        setError(
            email,
            emailError,
            "Email address is required."
        );

        return false;
    }

    if (!emailPattern.test(value)) {

        setError(
            email,
            emailError,
            "Enter a valid email address."
        );

        return false;
    }

    setValid(email, emailError);

    return true;
}


/* =========================================================
   PHONE VALIDATION
========================================================= */

function validatePhone() {

    const value = phone.value.trim();

    if (value === "") {

        setError(
            phone,
            phoneError,
            "Phone number is required."
        );

        return false;
    }

    if (!/^[0-9]{10}$/.test(value)) {

        setError(
            phone,
            phoneError,
            "Phone number must contain exactly 10 digits."
        );

        return false;
    }

    setValid(phone, phoneError);

    return true;
}


/* =========================================================
   PASSWORD RULES
========================================================= */

function checkPasswordRules(value) {

    return {

        length:
            value.length >= 8,

        upper:
            /[A-Z]/.test(value),

        lower:
            /[a-z]/.test(value),

        number:
            /[0-9]/.test(value),

        special:
            /[!@#$%^&*(),.?":{}|<>]/.test(value)

    };
}


/* =========================================================
   UPDATE PASSWORD RULE
========================================================= */

function updateRule(id, condition) {

    const element =
        document.getElementById(id);

    const icon =
        element.querySelector("span");

    if (condition) {

        element.classList.add("valid-rule");

        icon.textContent = "✓";

    } else {

        element.classList.remove("valid-rule");

        icon.textContent = "○";
    }
}


/* =========================================================
   PASSWORD STRENGTH
========================================================= */

function updatePasswordStrength() {

    const value = password.value;

    const rules =
        checkPasswordRules(value);

    updateRule(
        "ruleLength",
        rules.length
    );

    updateRule(
        "ruleUpper",
        rules.upper
    );

    updateRule(
        "ruleLower",
        rules.lower
    );

    updateRule(
        "ruleNumber",
        rules.number
    );

    updateRule(
        "ruleSpecial",
        rules.special
    );


    let score = 0;

    if (rules.length) score++;

    if (rules.upper) score++;

    if (rules.lower) score++;

    if (rules.number) score++;

    if (rules.special) score++;


    if (value.length === 0) {

        strengthBar.style.width = "0%";

        strengthText.textContent =
            "Password strength";

        strengthBar.style.background =
            "#d1d5db";

        return;
    }


    if (score <= 2) {

        strengthBar.style.width = "35%";

        strengthBar.style.background =
            "#dc2626";

        strengthText.textContent =
            "Weak password";

    } else if (score === 3 || score === 4) {

        strengthBar.style.width = "70%";

        strengthBar.style.background =
            "#e59b25";

        strengthText.textContent =
            "Medium password";

    } else {

        strengthBar.style.width = "100%";

        strengthBar.style.background =
            "#22a55a";

        strengthText.textContent =
            "Strong password";
    }
}


/* =========================================================
   PASSWORD VALIDATION
========================================================= */

function validatePassword() {

    const value = password.value;

    const rules =
        checkPasswordRules(value);

    if (value === "") {

        setError(
            password,
            passwordError,
            "Password is required."
        );

        return false;
    }

    if (!rules.length) {

        setError(
            password,
            passwordError,
            "Password must contain at least 8 characters."
        );

        return false;
    }

    if (!rules.upper) {

        setError(
            password,
            passwordError,
            "Password needs an uppercase letter."
        );

        return false;
    }

    if (!rules.lower) {

        setError(
            password,
            passwordError,
            "Password needs a lowercase letter."
        );

        return false;
    }

    if (!rules.number) {

        setError(
            password,
            passwordError,
            "Password needs a number."
        );

        return false;
    }

    if (!rules.special) {

        setError(
            password,
            passwordError,
            "Password needs a special character."
        );

        return false;
    }

    setValid(password, passwordError);

    return true;
}


/* =========================================================
   CONFIRM PASSWORD
========================================================= */

function validateConfirmPassword() {

    const value =
        confirmPassword.value;

    if (value === "") {

        setError(
            confirmPassword,
            confirmPasswordError,
            "Please confirm your password."
        );

        return false;
    }

    if (value !== password.value) {

        setError(
            confirmPassword,
            confirmPasswordError,
            "Passwords do not match."
        );

        return false;
    }

    setValid(
        confirmPassword,
        confirmPasswordError
    );

    return true;
}


/* =========================================================
   TERMS VALIDATION
========================================================= */

function validateTerms() {

    if (!terms.checked) {

        termsError.textContent =
            "You must accept the terms and conditions.";

        return false;
    }

    termsError.textContent = "";

    return true;
}


/* =========================================================
   REAL-TIME EVENTS
========================================================= */

fullName.addEventListener(
    "input",
    validateFullName
);

email.addEventListener(
    "input",
    validateEmail
);

phone.addEventListener(
    "input",
    validatePhone
);

password.addEventListener(
    "input",
    function () {

        updatePasswordStrength();

        validatePassword();

        if (confirmPassword.value !== "") {
            validateConfirmPassword();
        }
    }
);

confirmPassword.addEventListener(
    "input",
    validateConfirmPassword
);

terms.addEventListener(
    "change",
    validateTerms
);


/* =========================================================
   ONLY ALLOW NUMBERS IN PHONE
========================================================= */

phone.addEventListener(
    "input",
    function () {

        this.value =
            this.value.replace(/\D/g, "");

        if (this.value.length > 10) {
            this.value =
                this.value.substring(0, 10);
        }

        validatePhone();
    }
);


/* =========================================================
   FORM SUBMISSION
========================================================= */

form.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();


        const validName =
            validateFullName();

        const validEmail =
            validateEmail();

        const validPhone =
            validatePhone();

        const validPassword =
            validatePassword();

        const validConfirmPassword =
            validateConfirmPassword();

        const validTerms =
            validateTerms();


        if (
            !validName ||
            !validEmail ||
            !validPhone ||
            !validPassword ||
            !validConfirmPassword ||
            !validTerms
        ) {

            showDynamicMessage(
                "Please correct the highlighted fields before submitting.",
                "error"
            );

            return;
        }


        showDynamicMessage(
            "Validation successful. Creating your account...",
            "success"
        );


        /*
         * Submit the form to Express after
         * client-side validation.
         */

        setTimeout(() => {

            form.submit();

        }, 700);

    }
);


/* =========================================================
   DYNAMIC MESSAGE
========================================================= */

function showDynamicMessage(
    message,
    type
) {

    dynamicMessage.textContent =
        message;

    dynamicMessage.className =
        "dynamic-message show " + type;
}


/* =========================================================
   SHOW / HIDE PASSWORD
========================================================= */

const passwordButtons =
    document.querySelectorAll(
        ".show-password"
    );

passwordButtons.forEach(
    function (button) {

        button.addEventListener(
            "click",
            function () {

                const targetId =
                    this.getAttribute("data-target");

                const target =
                    document.getElementById(
                        targetId
                    );


                if (
                    target.type ===
                    "password"
                ) {

                    target.type =
                        "text";

                    this.textContent =
                        "Hide";

                } else {

                    target.type =
                        "password";

                    this.textContent =
                        "Show";
                }

            }
        );

    }
);


/* =========================================================
   CLIENT-SIDE ROUTING
========================================================= */

const sections =
    document.querySelectorAll(
        ".page-section"
    );

const navLinks =
    document.querySelectorAll(
        ".nav-link"
    );


function navigateTo(route) {

    sections.forEach(
        function (section) {

            section.classList.remove(
                "active-section"
            );

        }
    );


    const targetSection =
        document.getElementById(route);


    if (targetSection) {

        targetSection.classList.add(
            "active-section"
        );
    }


    navLinks.forEach(
        function (link) {

            link.classList.remove(
                "active"
            );


            if (
                link.getAttribute(
                    "data-route"
                ) === route
            ) {

                link.classList.add(
                    "active"
                );
            }

        }
    );


    window.history.pushState(
        {
            route: route
        },
        "",
        "#" + route
    );


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


/* =========================================================
   NAVIGATION LINKS
========================================================= */

navLinks.forEach(
    function (link) {

        link.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                const route =
                    this.getAttribute(
                        "data-route"
                    );

                navigateTo(route);

            }
        );

    }
);


/* =========================================================
   HERO BUTTON ROUTING
========================================================= */

const routeButtons =
    document.querySelectorAll(
        "[data-route-button]"
    );

routeButtons.forEach(
    function (button) {

        button.addEventListener(
            "click",
            function () {

                const route =
                    this.getAttribute(
                        "data-route-button"
                    );

                navigateTo(route);

            }
        );

    }
);


/* =========================================================
   HANDLE BROWSER BACK / FORWARD
========================================================= */

window.addEventListener(
    "popstate",
    function () {

        const route =
            window.location.hash
                .replace("#", "") ||
            "home";

        navigateWithoutHistory(route);

    }
);


/*
 * Used when browser back/forward is clicked.
 * Prevents creating another history entry.
 */

function navigateWithoutHistory(route) {

    sections.forEach(
        function (section) {

            section.classList.remove(
                "active-section"
            );

        }
    );


    const target =
        document.getElementById(route);


    if (target) {

        target.classList.add(
            "active-section"
        );

    } else {

        document
            .getElementById("home")
            .classList.add(
                "active-section"
            );
    }


    navLinks.forEach(
        function (link) {

            link.classList.remove(
                "active"
            );


            if (
                link.getAttribute(
                    "data-route"
                ) === route
            ) {

                link.classList.add(
                    "active"
                );

            }

        }
    );
}


/* =========================================================
   MOBILE MENU
========================================================= */

const menuButton =
    document.getElementById(
        "menuButton"
    );

const navigation =
    document.getElementById(
        "navigation"
    );


menuButton.addEventListener(
    "click",
    function () {

        navigation.classList.toggle(
            "mobile-open"
        );

    }
);


/* Close mobile menu after navigation */

navLinks.forEach(
    function (link) {

        link.addEventListener(
            "click",
            function () {

                navigation.classList.remove(
                    "mobile-open"
                );

            }
        );

    }
);


/* =========================================================
   INITIAL ROUTE
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const route =
            window.location.hash
                .replace("#", "") ||
            "home";

        navigateWithoutHistory(route);

        updatePasswordStrength();

    }
);